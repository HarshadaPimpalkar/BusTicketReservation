package com.app.pojos;

public enum SexType {
	MALE,FEMALE,OTHER
}
