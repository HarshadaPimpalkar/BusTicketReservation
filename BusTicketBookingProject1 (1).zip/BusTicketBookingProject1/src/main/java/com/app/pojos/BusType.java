package com.app.pojos;

public enum BusType {
	SEATER_AC,SEATER_NON_AC, SLEEPER_AC,SLEEPER_NON_AC
	

}
