package com.app.pojos;

public enum CustomerRoleType {
ADMIN,AGENT,CUSTOMER
}
