package com.app.pojos;

public enum PaymentType {
	CREDIT_CARD,DEBIT_CARD,NET_BANKING, UPI, CASH

}
